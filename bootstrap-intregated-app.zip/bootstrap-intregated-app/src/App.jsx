import React from 'react'
import withSection from './hoc/withSection'
import Navbar from './components/Navbar'
import HeroComponent from './components/Hero'
import AboutComponent from './components/About'
import StatsComponent from './components/Stats'
import WhyChooseUsComponent from './components/WhyChooseUs'
import Footer from './components/Footer'

// create wrapped sections (keeps your background color choices)
const Hero = withSection(HeroComponent, 'transparent') // hero stays dark from .hero class
const About = withSection(AboutComponent, 'var(--dark-800)')
const Stats = withSection(StatsComponent, 'var(--dark-900)')
const WhyChooseUs = withSection(WhyChooseUsComponent, 'var(--dark-800)')

export default function App() {
  return (
    <>
      {/* If you prefer CDN bootstrap, you can keep a link in index.html.
          Or install bootstrap and import it in main.jsx */}
      <Navbar />
      <Hero />
      <About />
      <Stats />
      <WhyChooseUs />
      <Footer />
    </>
  )
}
