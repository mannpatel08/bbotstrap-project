import React from 'react'

const Footer = () => {
  return (
    <footer style={{ backgroundColor: '#0f172a', padding: '30px 0' }}>
      <div className="container d-flex justify-content-between align-items-center flex-wrap">
        <p style={{ color: 'var(--muted)', margin: 0 }}>
          © Copyright 2025 techguru All rights reserved
        </p>
        <div>
          <span style={{ color: '#a78bfa', marginRight: '20px' }}>Follow Us:</span>
          <a href="#" style={{ color: 'white', marginRight: '15px', textDecoration: 'none' }}>f</a>
          <a href="#" style={{ color: 'white', marginRight: '15px', textDecoration: 'none' }}>🌐</a>
          <a href="#" style={{ color: 'white', textDecoration: 'none' }}>in</a>
        </div>
      </div>
    </footer>
  )
}

export default Footer
