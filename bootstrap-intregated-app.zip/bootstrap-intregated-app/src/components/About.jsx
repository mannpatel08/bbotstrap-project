import React from 'react'

const AboutComponent = () => {
  return (
    <div className="container about" id="about">
      <div className="row align-items-center">
        <div className="col-lg-6">
          <div className="position-relative">
            <img
              src="https://images.unsplash.com/photo-1552664730-d307ca884978?w=500&h=400&fit=crop"
              alt="Business professional"
              style={{ width: '100%', borderRadius: '15px' }}
            />
            <img
              src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=300&fit=crop"
              alt="Tech professional"
              style={{
                position: 'absolute',
                bottom: '-30px',
                right: '-30px',
                width: '60%',
                borderRadius: '15px',
                border: '5px solid #1e293b'
              }}
            />
          </div>
        </div>

        <div className="col-lg-6">
          <p style={{ color: '#3b82f6', marginBottom: '10px' }}>— About Us</p>
          <h2 style={{
            fontSize: '42px',
            fontWeight: 'bold',
            marginBottom: '20px',
            color: 'white'
          }}>
            Unlock Your Business<span style={{ color: 'var(--accent)' }}>Potential</span><br />
            <span style={{ color: 'var(--accent)' }}>with Our best Cutting-Edge IT</span><br />
            Solutions to grow
          </h2>
          <p style={{ color: 'var(--muted)', marginBottom: '30px' }}>
            Transform your business with our innovative IT solutions, tailored to address your unique challenges and drive growth in today's digital landscape.
          </p>

          <div className="row">
            <div className="col-md-6 mb-3">
              <div className="d-flex align-items-start">
                <span style={{ color: '#10b981', marginRight: '10px', fontSize: '20px' }}>✓</span>
                <div>
                  <h6 style={{ color: 'white', marginBottom: '5px' }}>Customized Solutions for Every Business</h6>
                </div>
              </div>
            </div>

            <div className="col-md-6 mb-3">
              <div className="d-flex align-items-start">
                <span style={{ color: '#10b981', marginRight: '10px', fontSize: '20px' }}>✓</span>
                <div>
                  <h6 style={{ color: 'white', marginBottom: '5px' }}>Scalable Infrastructure for Growth</h6>
                </div>
              </div>
            </div>

            <div className="col-md-6 mb-3">
              <div className="d-flex align-items-start">
                <span style={{ color: '#10b981', marginRight: '10px', fontSize: '20px' }}>✓</span>
                <div>
                  <h6 style={{ color: 'white', marginBottom: '5px' }}>Enhanced Security and Data Protection</h6>
                </div>
              </div>
            </div>

            <div className="col-md-6 mb-3">
              <div className="d-flex align-items-start">
                <span style={{ color: '#10b981', marginRight: '10px', fontSize: '20px' }}>✓</span>
                <div>
                  <h6 style={{ color: 'white', marginBottom: '5px' }}>Continuous system monitoring and expert support</h6>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  )
}

export default AboutComponent
