import React from 'react'

const WhyChooseUsComponent = () => {
  return (
    <div className="container why" id="why">
      <div className="row align-items-center">
        <div className="col-lg-6">
          <p style={{ color: '#3b82f6', marginBottom: '10px' }}>— Why Choose Us</p>
          <h2 style={{
            fontSize: '42px',
            fontWeight: 'bold',
            marginBottom: '20px',
            color: 'white'
          }}>
            Elevate Growth <span style={{ color: 'var(--accent)' }}>with Our Cutting-Edge IT</span>
            <span style={{ color: 'white' }}> Solutions</span><br />
            for Success
          </h2>
          <p style={{ color: 'var(--muted)', marginBottom: '30px' }}>
            Innovating and empowering businesses with tailored solutions for success and growth. Innovating and empowering
          </p>

          <div className="mb-4">
            <div className="d-flex justify-content-between mb-2">
              <span style={{ color: 'white' }}>Camping Launches</span>
              <span style={{ color: 'white' }}>75%</span>
            </div>
            <div style={{
              height: '8px',
              backgroundColor: '#1e293b',
              borderRadius: '10px',
              overflow: 'hidden'
            }}>
              <div style={{
                width: '75%',
                height: '100%',
                background: 'linear-gradient(90deg, #667eea 0%, #764ba2 100%)',
                borderRadius: '10px'
              }}></div>
            </div>
          </div>

          <div className="mb-4">
            <div className="d-flex justify-content-between mb-2">
              <span style={{ color: 'white' }}>Innovation Design</span>
              <span style={{ color: 'white' }}>90%</span>
            </div>
            <div style={{
              height: '8px',
              backgroundColor: '#1e293b',
              borderRadius: '10px',
              overflow: 'hidden'
            }}>
              <div style={{
                width: '90%',
                height: '100%',
                background: 'linear-gradient(90deg, #3b82f6 0%, #2563eb 100%)',
                borderRadius: '10px'
              }}></div>
            </div>
          </div>

        </div>

        <div className="col-lg-6">
          <img
            src="https://images.unsplash.com/photo-1551434678-e076c223a692?w=800&h=600&fit=crop"
            alt="Tech workspace"
            style={{ width: '100%', borderRadius: '15px' }}
          />
        </div>
      </div>
    </div>
  )
}

export default WhyChooseUsComponent
