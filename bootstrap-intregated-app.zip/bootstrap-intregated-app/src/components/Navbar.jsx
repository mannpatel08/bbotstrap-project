import React, { useState } from 'react'

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <nav className="navbar navbar-expand-lg navbar-dark" style={{ backgroundColor: '#1a2332' }}>
      <div className="container">
        <a className="navbar-brand d-flex align-items-center" href="#home" style={{ textDecoration: 'none', color: 'inherit' }}>
          <div style={{
            width: '40px',
            height: '40px',
            backgroundColor: '#7c3aed',
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            marginRight: '10px'
          }}>
            <span style={{ color: 'white', fontSize: '20px', fontWeight: 'bold' }}>T</span>
          </div>
          <span style={{ fontSize: '24px', fontWeight: 'bold' }}>
            Tech<span style={{ color: '#ef4444' }}>Guru</span>
          </span>
        </a>

        <button
          className="navbar-toggler"
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className={`collapse navbar-collapse ${isOpen ? 'show' : ''}`}>
          <ul className="navbar-nav ms-auto mb-2 mb-lg-0" style={{ alignItems: 'center' }}>
            <li className="nav-item"><a className="nav-link" href="#home">Home</a></li>
            <li className="nav-item"><a className="nav-link" href="#about">About</a></li>
            <li className="nav-item"><a className="nav-link" href="#pages">Pages</a></li>
            <li className="nav-item"><a className="nav-link" href="#services">Services</a></li>
            <li className="nav-item"><a className="nav-link" href="#shop">Shop</a></li>
            <li className="nav-item"><a className="nav-link" href="#blog">Blog</a></li>
            <li className="nav-item"><a className="nav-link" href="#contact">Contact</a></li>
            <li>
              <button className="btn btn-primary ms-3" style={{
                backgroundColor: '#3b82f6',
                border: 'none',
                padding: '10px 25px',
                borderRadius: '5px'
              }}>
                Get In Touch →
              </button>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  )
}

export default Navbar
