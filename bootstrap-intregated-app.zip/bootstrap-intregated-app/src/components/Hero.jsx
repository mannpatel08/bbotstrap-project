import React from 'react'

const HeroComponent = () => {
  return (
    <div className="container hero" id="home">
      <div className="row align-items-center" style={{ minHeight: '600px' }}>
        <div className="col-lg-6">
          <div className="d-flex align-items-center mb-3">
            <span style={{
              width: '50px',
              height: '50px',
              backgroundColor: '#3b82f6',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              marginRight: '15px'
            }}>
              ⚡
            </span>
            <span style={{ color: 'var(--muted)' }}>IT Solutions Designed for Your Success</span>
          </div>

          <h1 style={{
            fontSize: '56px',
            fontWeight: 'bold',
            lineHeight: '1.2',
            marginBottom: '30px',
            color: 'white'
          }}>
            Tailored IT <span className="accent">Strategies</span><br />
            <span className="accent">to Drive Your Business</span><br />
            Forward
          </h1>

          <p style={{ color: 'var(--muted)', fontSize: '18px', marginBottom: '30px' }}>
            From strategic IT consulting to seamless implementation, we deliver tailored solutions that drive efficiency
          </p>
        </div>

        <div className="col-lg-6">
          <img
            src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&h=600&fit=crop"
            alt="IT Solutions"
            style={{ width: '100%', borderRadius: '15px' }}
          />
        </div>
      </div>
    </div>
  )
}

export default HeroComponent
