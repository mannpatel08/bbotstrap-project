import React from 'react'

const StatsComponent = () => {
  const stats = [
    { icon: '🏆', number: '120+', label: 'Creative Plus award' },
    { icon: '👥', number: '300+', label: 'Expert Team Members' },
    { icon: '💬', number: '20M', label: 'Happy Clients Review' },
    { icon: '📁', number: '1.5K', label: 'Project Completed' }
  ]

  return (
    <div className="container stats" id="stats" style={{ paddingTop: 30, paddingBottom: 30 }}>
      <div className="row">
        {stats.map((stat, index) => (
          <div key={index} className="col-lg-3 col-md-6 mb-4 text-center">
            <div style={{
              width: '70px',
              height: '70px',
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 20px',
              fontSize: '30px'
            }}>
              {stat.icon}
            </div>

            <h2 className="stat-number" style={{ color: 'white' }}>{stat.number}</h2>
            <p style={{ color: 'var(--muted)' }}>{stat.label}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

export default StatsComponent
