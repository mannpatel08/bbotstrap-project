import React from 'react'

/**
 * withSection HOC
 * Wraps a component in a section with background color and consistent padding.
 */
const withSection = (Component, backgroundColor = 'transparent') => {
  return (props) => (
    <section style={{ backgroundColor, padding: '60px 0' }} className="section-wrapper">
      <Component {...props} />
    </section>
  );
};

export default withSection;
