src/
├── hoc/
│   └── withFadeIn.jsx          // HOC for fade-in animation
├── components/
│   ├── TopBar.jsx              // Top contact bar
│   ├── Navigation.jsx          // Main navigation
│   ├── Sidebar.jsx             // Fixed sidebar
│   ├── HeroSection.jsx         // Hero section
│   └── EnvatoBadge.jsx         // Buy now badge
└── App.jsx                     // Main app component